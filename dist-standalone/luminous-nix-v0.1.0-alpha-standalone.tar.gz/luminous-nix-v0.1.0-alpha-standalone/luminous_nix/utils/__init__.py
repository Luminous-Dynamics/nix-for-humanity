"""Shared utilities and helpers."""
