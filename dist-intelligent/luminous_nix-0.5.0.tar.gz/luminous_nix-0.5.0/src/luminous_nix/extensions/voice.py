"""Voice interface with pipecat."""
